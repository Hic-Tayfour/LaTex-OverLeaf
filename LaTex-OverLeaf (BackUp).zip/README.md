Olá, tudo bem? Espero que sim.

Este repositório trata do meu desenvolvimento pessoal em LaTeX, utilizando o OverLeaf para o desenvolvimento de um programa de formatação em ABNT para os meus trabalhos acadêmicos. Aqui, compartilharei meus erros, acertos, rascunhos e resumos para aqueles que têm interesse em aprender a usar essa ferramenta. Faça bom uso do material aqui presente.

Atenciosamente, Hicham Tayfour.
